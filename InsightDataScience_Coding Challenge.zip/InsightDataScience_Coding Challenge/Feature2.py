# Feature 2: Identify the 10 resources that consume the most bandwidth on the site
import resource
# the same but with a dict
dict={}
for i in range(0,10000000):
	dict[i]='abcdefg'
	if len(dict) % 1000000 ==0:
		print(len(dict),resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1000)


# Solution 2:

import time
from functools import wraps
 
 
def fn_timer(function):
    @wraps(function)
    def function_timer(*args, **kwargs):
        t0 = time.time()
        result = function(*args, **kwargs)
        t1 = time.time()
        print ("Total time running %s: %s seconds" %
               (function.func_name, str(t1-t0))
               )
        return result
    return function_timer

