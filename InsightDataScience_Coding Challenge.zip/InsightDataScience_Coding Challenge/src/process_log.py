// your Python code to implement the features could be placed here
// note that you may use any language, there is no preference towards Python
