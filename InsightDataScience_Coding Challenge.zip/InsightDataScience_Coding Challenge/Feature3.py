# Feature 3: List the top 10 busiest (or most frequently visited) 60-minute periods

from collections import Counter

log = """Jan/01/2017   08:23:45
Jan/01/2017   15:54:21
Jan/01/2017   15:50:21
Jan/01/2017   15:52:21
Jan/02/2017   04:02:39
Jan/03/2017   06:33:12"""

# in24.inetnebr.com - - [01/Aug/1995:00:00:01 -0400] "GET /shuttle/missions/sts-68/news/sts-68-mcc-05.txt HTTP/1.0" 200 1839
# 208.271.69.50 - - [01/Aug/1995:00:00:02 -400] "POST /login HTTP/1.0" 401 1420
# 208.271.69.50 - - [01/Aug/1995:00:00:04 -400] "POST /login HTTP/1.0" 200 1420
# uplherc.upl.com - - [01/Aug/1995:00:00:07 -0400] "GET / HTTP/1.0" 304 0
# uplherc.upl.com - - [01/Aug/1995:00:00:08 -0400] "GET /images/ksclogo-medium.gif HTTP/1.0" 304 0

portion = 10
interval = 60

counter = Counter()

for line in log.split("\n"):
    time = line.split()[-1]
    hour, minute, second = map(int, time.split(':'))
    since_midnight = hour * 60 + minute
    counter[since_midnight // portion] += 1

for slot, count in counter.most_common():
    print("%02d:%02d -> %02d:%02d - %d" % ((slot * portion) / 60,
                                           (slot * portion) % 60,
                                           ((slot + 1) * portion) / 60,
                                           ((slot + 1) * portion) % 60,
                                           count))


