<?php
header("Access-Control-Allow-Origin:*");

<!-- Feature 4: Detect patterns of three failed login attempts from the same IP address over 20 seconds so that all further
attempts to the site can be blocked for 5 minutes. Log those possible security breaches. -->

session_start();
$ipaddress = '';
if (getenv('HTTP_CLIENT_IP'))
    $ipaddress = getenv('HTTP_CLIENT_IP');
else if(getenv('HTTP_X_FORWARDED_FOR'))
    $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
else if(getenv('HTTP_X_FORWARDED'))
    $ipaddress = getenv('HTTP_X_FORWARDED');
else if(getenv('HTTP_FORWARDED_FOR'))
    $ipaddress = getenv('HTTP_FORWARDED_FOR');
else if(getenv('HTTP_FORWARDED'))
    $ipaddress = getenv('HTTP_FORWARDED');
else if(getenv('REMOTE_ADDR'))
    $ipaddress = getenv('REMOTE_ADDR');
else
    $ipaddress = 'UNKNOWN';

$loginDate = date("Y-m-d H:i:s");
$Error ="";
$successMessage ="";
if (isset($_POST['submit'])){
if ( !( $_POST['cnumber'] == "" && $_POST['password'] == "")){
    $cnumber=$_POST['cnumber'];
    $password= sha1($_POST['password']);
    $cnumber = filter_var($cnumber, FILTER_SANITIZE_NUMBER_INT);

if (filter_var($cnumber, FILTER_VALIDATE_INT)){
$con=mysqli_connect("localhost","root","","users");

$result = mysqli_query($con, "SELECT * FROM users WHERE contractNumber='$cnumber' AND password='$password'");
$data = mysqli_num_rows($result);

if($data==1){
    $_SESSION['login_user']=$cnumber;
    mysqli_query($con, "INSERT INTO `users`.`logs`(`contractNumber`, `lastLogin`, `ipAddress`) VALUES ('$cnumber', '$loginDate', '$ipaddress')");
    header('Location: profile.php');
} else {
    $Error ="Invalid Contract Number or Password.";
    mysqli_query($con, "UPDATE users SET loginAttempt = loginAttempt + 1 WHERE contractNumber = '$cnumber' ");
    print_r(mysqli_affected_rows($con));
} 
    mysqli_close($con);
} else {
    $Error ="Invalid Contract Number.";
 }
} else {
    $Error ="Contract Number or Password is Empty.";
}
}

?>
